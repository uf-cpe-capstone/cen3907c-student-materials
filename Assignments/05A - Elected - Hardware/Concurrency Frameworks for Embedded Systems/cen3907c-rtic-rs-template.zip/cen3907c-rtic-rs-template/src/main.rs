#![no_std]
#![no_main]

use rtic::app;
use panic_halt as _;

mod usb_manager;

#[app(device = adafruit_feather_rp2040::pac, peripherals = true, dispatchers = [RTC_IRQ])]
mod app {

    // Board specific imports
    use adafruit_feather_rp2040::hal as hal;
    use adafruit_feather_rp2040::{
        Pins,
        XOSC_CRYSTAL_FREQ,
    };
    use hal::{
        clocks::init_clocks_and_plls,
        Clock,
        watchdog::Watchdog,
        Sio,
        pio::PIOExt,
    };
    use embedded_hal::digital::v2::{
        StatefulOutputPin,
        OutputPin,
    };

    // TODO: Bring necessary items into scope for NeoPixels!

    /**************************************************************************
    DATA STRUCTURE setup
    **************************************************************************/
    use usb_device::class_prelude::*;
    use crate::usb_manager::UsbManager;
    #[shared]
    struct DataCommon {
        usb_manager: UsbManager,
    }

    #[local]
    struct DataLocal {
        // TODO: Add the required object types for the LED and NeoMatrix!
    }

    use systick_monotonic::ExtU64;
    #[monotonic(binds = SysTick, default = true)]
    type MyMono = systick_monotonic::Systick<1000>;

    /**************************************************************************
    INIT ROUTINE
    **************************************************************************/
    #[init(local = [usb_bus: Option<usb_device::bus::UsbBusAllocator<hal::usb::UsbBus>> = None])]
    fn init(cx: init::Context) -> (DataCommon, DataLocal, init::Monotonics) {
        
        let mut resets = cx.device.RESETS;
        let mut watchdog = Watchdog::new(cx.device.WATCHDOG);
        let clocks = init_clocks_and_plls(
            XOSC_CRYSTAL_FREQ,
            cx.device.XOSC,
            cx.device.CLOCKS,
            cx.device.PLL_SYS,
            cx.device.PLL_USB,
            &mut resets,
            &mut watchdog,
        )
        .ok()
        .unwrap();

        /**********************************************************************
        Setup the USB driver and USB Manager for serial port printing
        **********************************************************************/
        let usb_bus: &'static _ =
            cx.local.usb_bus.insert(UsbBusAllocator::new(hal::usb::UsbBus::new(
                cx.device.USBCTRL_REGS,
                cx.device.USBCTRL_DPRAM,
                clocks.usb_clock,
                true,
                &mut resets,
            )));
        let usb_manager = UsbManager::new(usb_bus);

        /**********************************************************************
        TODO: Setup the GPIO and led pin 
        **********************************************************************/

        /**********************************************************************
        TODO: Setup the PIO NeoPixel driver
        **********************************************************************/
        
        /**********************************************************************
        Setup tasks!
        **********************************************************************/
        print::spawn("Welcome to my RTIC App!\r\n").unwrap();
        // Start the heartbeat in 3 seconds
        heartbeat::spawn().unwrap();

        // TODO: Start the LED blinking task and the NeoMatrix update task!

        // Return the resource structs
        (
            DataCommon {
                usb_manager: usb_manager,
            },
            DataLocal {
                // TODO: Fill in the objects for the LED and NeoMatrix
            },
            init::Monotonics(systick_monotonic::Systick::new(cx.core.SYST, 125_000_000)),
        )
    }


    /**************************************************************************
    USB Interrupt task -- keeps the host happy and reads any available serial data
    **************************************************************************/
    #[task(binds = USBCTRL_IRQ, shared = [usb_manager])]
    fn usb_task(cx: usb_task::Context) {
        let mut usb_manager = cx.shared.usb_manager;
        (usb_manager).lock(
            |usb_manager_l| {
                usb_manager_l.interrupt();
            }
        );
    }

    /**************************************************************************
    Print Task -- prints a string to the serial port.
    **************************************************************************/
    #[task(shared = [usb_manager])]
    fn print(cx: print::Context, s: &'static str) {
        let mut usb_manager = cx.shared.usb_manager;
        usb_manager.lock(
            |usb_manager_l| {
                usb_manager_l.write(s);
            }
        );
    }

    /**************************************************************************
    Heartbeat Task -- once started, the heartbeat will print to serial port
        every 2 seconds.
    **************************************************************************/
    #[task]
    fn heartbeat(_cx: heartbeat::Context) {
        print::spawn("<3 heartbeat\r\n").unwrap();
        heartbeat::spawn_after(2000.millis()).unwrap();
    }

    /**************************************************************************
    TODO: LED Task -- Blinks the onboard LED at 10Hz
    **************************************************************************/


    /**************************************************************************
    TODO: NeoMatrix update task -- displays a random pixel w/ random color at 5Hz
    **************************************************************************/

} // mod app